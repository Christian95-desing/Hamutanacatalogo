// En tu archivo barrel.js
// export {default as  Image_Portada } from '~/media/hamutana-galery/portada.jpg?jsx';
// export {default  as Image_Fondo } from '~/media/hamutana-galery/fondo-principal.jpg?jsx';

